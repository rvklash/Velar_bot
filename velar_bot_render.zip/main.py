
from flask import Flask, request
import telebot
import os

API_TOKEN = os.environ.get("BOT_TOKEN")
bot = telebot.TeleBot(API_TOKEN)

app = Flask(__name__)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    markup = telebot.types.InlineKeyboardMarkup()
    btn1 = telebot.types.InlineKeyboardButton("Azattyk Avenue", callback_data="azattyk")
    btn2 = telebot.types.InlineKeyboardButton("Center City", callback_data="center")
    btn3 = telebot.types.InlineKeyboardButton("Dostyk 1", callback_data="dostyk")
    markup.row(btn1)
    markup.row(btn2)
    markup.row(btn3)
    bot.send_message(message.chat.id, "Выберите интересующий вас жилой комплекс:", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    if call.data == "azattyk":
        bot.send_message(call.message.chat.id, "🏢 Azattyk Avenue:\n\nЦена от 420 000 ₸/м² до 500 000 ₸/м²\n\nИпотека от Altyn Bank\nРассрочка 50% + до конца строительства (4 кв. 2026)\n\nАдрес: Азаттык 21 (ост. Юность, БСМП)\nПлощади от 40 до 118 м²\nСдача: конец 2026 года")
    elif call.data == "center":
        bot.send_message(call.message.chat.id, "🏢 Center City:\n\nОсталось 2 квартиры:\n— 2-комн., 80 м², 9 этаж, черновая, 450 000 ₸/м² → 36 млн ₸, окна на Азаттык\n— 3-комн., 107 м², черновая, 46.2 млн ₸, окна на Азаттык")
    elif call.data == "dostyk":
        bot.send_message(call.message.chat.id, "🏢 Dostyk 1:\n\nОсталась 1 квартира в чистовой отделке:\n3-комн., кухня-студия + 2 спальни, распашонка\n87 м², 9 этаж, окна в обе стороны двора\nЦена: 33 813 000 ₸ (390 000 ₸/м²)")

@app.route('/')
def home():
    return "Bot is alive!"

@app.route('/' + API_TOKEN, methods=['POST'])
def getMessage():
    json_str = request.get_data().decode('UTF-8')
    update = telebot.types.Update.de_json(json_str)
    bot.process_new_updates([update])
    return 'ok', 200

@app.route('/setwebhook', methods=['GET'])
def set_webhook():
    s = bot.set_webhook(url=os.environ.get("WEBHOOK_URL") + API_TOKEN)
    if s:
        return "Webhook setup ok"
    else:
        return "Webhook setup failed"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
